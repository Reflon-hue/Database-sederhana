<?php
$host     = 'localhost';     // Alamat server MySQL
$username = 'root';          // Username MySQL
$password = '';              // Password MySQL (kosong secara default di XAMPP)
$dbname   = 'db_pelajaran';  // Nama database

// Membuat koneksi ke database MySQL
$conn = new mysqli($host, $username, $password, $dbname);

// Memeriksa apakah koneksi berhasil
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
