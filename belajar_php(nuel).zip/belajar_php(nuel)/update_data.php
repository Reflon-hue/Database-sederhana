<?php
include('koneksi.php');

$id = $_POST['id'];
$username = $_POST['username'];
$password = $_POST['password'];

if (!empty($password)) {
    // Jika password diisi, hash password baru
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $sql = "UPDATE users SET username='$username', password='$hashed_password' WHERE id=$id";
} else {
    // Jika password tidak diisi, hanya update username
    $sql = "UPDATE users SET username='$username' WHERE id=$id";
}

if ($conn->query($sql)) {
    header("Location: tampil_data.php"); // Redirect ke halaman tampil data
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>