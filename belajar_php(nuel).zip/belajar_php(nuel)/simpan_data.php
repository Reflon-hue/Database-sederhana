<?php
include('koneksi.php');

$username = $_POST['username'];
$password = $_POST['password'];

// Hash password sebelum disimpan (untuk keamanan)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Query untuk menyimpan data
$sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

if ($conn->query($sql)) {
    header("Location: tampil_data.php"); // Redirect ke halaman tampil data
    exit; // Tambahkan exit untuk menghentikan eksekusi setelah redirect
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
