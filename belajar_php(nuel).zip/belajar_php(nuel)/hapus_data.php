<?php
include('koneksi.php');

// Pastikan ID diterima dan valid
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Pastikan ID hanya angka

    // Gunakan prepared statement untuk keamanan
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id); // "i" artinya integer, untuk bind parameter

    if ($stmt->execute()) {
        header("Location: tampil_data.php"); // Redirect ke halaman tampil data
        exit;
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "ID tidak ditemukan.";
}

$conn->close();
?>
